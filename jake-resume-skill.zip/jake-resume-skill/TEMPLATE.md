# Jake's Resume — Full LaTeX Boilerplate

Use this as the structural foundation. Populate only the content sections. Do not alter the preamble or command definitions.

```latex
%-------------------------
% Resume in Latex
% Based on: Jake Gutierrez's template
% https://www.overleaf.com/latex/templates/jakes-resume/syzfjbzwjncs
% License: MIT
%-------------------------

\documentclass[letterpaper,11pt]{article}

\usepackage{latexsym}
\usepackage[empty]{fullpage}
\usepackage{titlesec}
\usepackage{marvosym}
\usepackage[usenames,dvipsnames]{color}
\usepackage{verbatim}
\usepackage{enumitem}
\usepackage[hidelinks]{hyperref}
\usepackage{fancyhdr}
\usepackage[english]{babel}
\usepackage{tabularx}
\input{glyphtounicode}

\pagestyle{fancy}
\fancyhf{}
\fancyfoot{}
\renewcommand{\headrulewidth}{0pt}
\renewcommand{\footrulewidth}{0pt}

% Margins
\addtolength{\oddsidemargin}{-0.5in}
\addtolength{\evensidemargin}{-0.5in}
\addtolength{\textwidth}{1in}
\addtolength{\topmargin}{-.5in}
\addtolength{\textheight}{1.0in}

\urlstyle{same}
\raggedbottom
\raggedright
\setlength{\tabcolsep}{0in}

% Section formatting
\titleformat{\section}{
  \vspace{-4pt}\scshape\raggedright\large
}{}{0em}{}[\color{black}\titlerule \vspace{-5pt}]

\pdfgentounicode=1

%-------------------------
% Custom commands
%-------------------------

\newcommand{\resumeItem}[1]{
  \item\small{
    {#1 \vspace{-2pt}}
  }
}

\newcommand{\resumeSubheading}[4]{
  \vspace{-2pt}\item
    \begin{tabular*}{0.97\textwidth}[t]{l@{\extracolsep{\fill}}r}
      \textbf{#1} & #2 \\
      \textit{\small#3} & \textit{\small #4} \\
    \end{tabular*}\vspace{-7pt}
}

\newcommand{\resumeSubSubheading}[2]{
    \item
    \begin{tabular*}{0.97\textwidth}{l@{\extracolsep{\fill}}r}
      \textit{\small#1} & \textit{\small #2} \\
    \end{tabular*}\vspace{-7pt}
}

\newcommand{\resumeProjectHeading}[2]{
    \item
    \begin{tabular*}{0.97\textwidth}{l@{\extracolsep{\fill}}r}
      \small#1 & #2 \\
    \end{tabular*}\vspace{-7pt}
}

\newcommand{\resumeSubItem}[1]{\resumeItem{#1}\vspace{-4pt}}

\renewcommand\labelitemii{$\vcenter{\hbox{\tiny$\bullet$}}$}

\newcommand{\resumeSubHeadingListStart}{\begin{itemize}[leftmargin=0.15in, label={}]}
\newcommand{\resumeSubHeadingListEnd}{\end{itemize}}
\newcommand{\resumeItemListStart}{\begin{itemize}}
\newcommand{\resumeItemListEnd}{\end{itemize}\vspace{-5pt}}

%-------------------------
% Document start
%-------------------------

\begin{document}

%----------HEADING----------
\begin{center}
    \textbf{\Huge \scshape FirstName LastName} \\ \vspace{1pt}
    \small 514-000-0000 $|$ \href{mailto:email@example.com}{\underline{email@example.com}} $|$
    \href{https://linkedin.com/in/YOURHANDLE}{\underline{linkedin.com/in/YOURHANDLE}} $|$
    \href{https://github.com/YOURGITHUB}{\underline{github.com/YOURGITHUB}}
\end{center}


%-----------TECHNICAL SKILLS-----------
\section{Technical Skills}
\begin{itemize}[leftmargin=0.15in, label={}]
  \small{\item{
    \textbf{Languages}{: Java, Python, TypeScript, HTML5, CSS3, SQL} \\
    \textbf{Frameworks}{: React, Next.js, Spring Boot, FastAPI, Django, Expo} \\
    \textbf{Developer Tools}{: Git, Supabase, PostgreSQL, MongoDB, Figma, VSCode, IntelliJ, GitHub, Azure DevOps, DigitalOcean, Linux, Claude}
  }}
\end{itemize}


%-----------EXPERIENCE-----------
\section{Experience}
\resumeSubHeadingListStart

  \resumeSubheading
    {Claude Builder Campus Ambassador}{January 2026 -- Present}
    {Anthropic | Wasserman Next Gen}{Montreal, QC, Canada}
    \resumeItemListStart
      \resumeItem{Selected as McGill's first Campus Ambassador, launching the Claude Builder Club to educate students on AI fluency, responsible AI use, and practical applications across all majors.}
      \resumeItem{Organized workshops, hackathons, and demo nights helping students leverage AI for resumes, technical interview prep, and side projects.}
    \resumeItemListEnd

  \resumeSubheading
    {Software Engineer Intern}{October 2025 -- Present}
    {Google Developer Groups -- McGill University | Next.js, Tailwind CSS, Supabase}{Montreal, QC, Canada}
    \resumeItemListStart
      \resumeItem{Built an Event Discovery \& Calendar System for McGill students, developing 6+ reusable React components with responsive design across mobile, tablet, and desktop viewports.}
      \resumeItem{Designed mobile-responsive navigation with cross-browser compatibility, meeting WCAG accessibility standards.}
      \resumeItem{Engineered dark/light theme toggle with persistent user preferences and smooth hover animations for event cards.}
      \resumeItem{Implemented Supabase OAuth 2.0 for secure student sign-in and streamlined event registration flow.}
    \resumeItemListEnd

\resumeSubHeadingListEnd


%-----------PROJECTS-----------
\section{Projects}
\resumeSubHeadingListStart

  \resumeProjectHeading
    {\textbf{Style It Yourself (SIY)} $|$ \emph{\small{FastAPI, Next.js, Supabase, Google Gemini API, Zustand}}}{January 2026}
    \resumeItemListStart
      \resumeItem{Architected RESTful backend with FastAPI serving 8+ endpoints for closet management, outfit validation, and AI recommendations using schema-first development with Pydantic models.}
      \resumeItem{Engineered color harmony recommendation engine using HSL algorithms (analogous ±30°, complementary 180°, triadic 120°) to generate coordinated outfit suggestions from a user's wardrobe.}
      \resumeItem{Integrated Google Gemini API for virtual try-on, enabling users to visualize clothing on uploaded photos before purchase.}
    \resumeItemListEnd

  \resumeProjectHeading
    {\textbf{Flight Management System} $|$ \emph{\small{Spring Boot, Next.js, PostgreSQL, JUnit, Gradle}}}{August 2025 -- December 2025}
    \resumeItemListStart
      \resumeItem{Led a team of 6 as Tech Lead to build a full-stack airline booking system with 28 RESTful API endpoints; managed GitHub backlog and reviewed 100\% of pull requests.}
      \resumeItem{Implemented JWT-based authentication with role-based access control using Spring Security and JPA.}
      \resumeItem{Authored 40+ unit and integration test cases achieving 74\% code coverage; mentored 5 teammates on Spring Boot, Next.js, and Zustand patterns.}
    \resumeItemListEnd

\resumeSubHeadingListEnd


%-----------EDUCATION-----------
\section{Education}
\resumeSubHeadingListStart

  \resumeSubheading
    {McGill University}{Montreal, QC, Canada}
    {Bachelor of Engineering in Computer Engineering}{August 2024 -- May 2028}
    \resumeItemListStart
      \resumeItem{GPA: 3.71/4.00 \textemdash\ Minor in Technological Entrepreneurship}
      \resumeItem{Societies: McGill Google Developer Group (Frontend Developer), McGill Ventures (Event Associate), Claude Builder Group (President -- Anthropic Campus Ambassador)}
    \resumeItemListEnd

\resumeSubHeadingListEnd

\end{document}
```
