---
name: jake-resume-latex
description: Generate a complete, paste-ready LaTeX resume using Jake's Overleaf template. Trigger when the user asks to generate, update, or convert their resume to LaTeX, or mentions Overleaf or Jake's template.
---

# Jake Resume LaTeX Skill

## Your Job

Take resume content from the user (pasted text or uploaded PDF) and output a complete, compilable LaTeX file using Jake's Resume template structure. The user will paste the output directly into Overleaf.

## Input

Accept resume data in either form:
- **Pasted text**: User pastes their resume content into chat.
- **Uploaded file**: User uploads a PDF or document. Extract the content from it.

If the input is ambiguous or incomplete, ask for the missing section before generating.

## Output Format

Always output in this order:

1. A brief summary (3–5 sentences max): what sections you found, any content decisions you made (e.g. truncated a bullet to fit one page, combined two roles), and any fields left as placeholders.
2. The full LaTeX source in a single fenced code block (` ```latex `).

Do not explain LaTeX syntax. Do not add commentary inside the code block. Do not output anything after the code block.

## Layout Rules

Use Jake's centered single-column header (name centered, contact info on one line below) and single-column body. Follow this section order exactly:

1. Technical Skills
2. Experience
3. Projects
4. Education

## Section Formatting Rules

### Header
- Name: `\textbf{\Huge \scshape {FirstName LastName}}`
- Contact row: phone `\small` | email as `\href{mailto:...}` | LinkedIn as `\href{...}` | GitHub as `\href{...}`
- Use `\begin{tabular*}{\textwidth}` for two-column layout

### Technical Skills
- Use a single `\begin{itemize}` with `[leftmargin=0.15in, label={}]`
- Each line: `\small{\textbf{Category}{: items, comma-separated}}`
- Categories: Languages, Frameworks, Developer Tools

### Experience
- Each role uses `\resumeSubheading{Title}{Date}{Company | Tech Stack}{Location}`
- Bullets use `\resumeItem{...}`
- Wrap all roles in `\resumeSubHeadingListStart` / `\resumeSubHeadingListEnd`
- Keep bullets tight: max 2 lines each, start with a strong action verb

### Projects
- Each project uses `\resumeProjectHeading{\textbf{Name} $|$ \emph{\small{Tech Stack}}}{Date}`
- Bullets use `\resumeItem{...}`
- Same list wrappers as Experience

### Education
- Use `\resumeSubheading{University}{Location}{Degree}{Date Range}`
- Include GPA and minor as `\resumeItem` bullets if present
- Include societies/clubs as a single `\resumeItem` bullet

## One-Page Rule

If the content risks overflowing one page:
- Trim bullet points to their most impactful line
- Remove weakest bullets first (oldest roles, least technical projects)
- Never remove section headers or roles entirely without telling the user

## LaTeX Boilerplate

Reference TEMPLATE.md for the full preamble, custom commands, and document structure. Do not modify the preamble or command definitions. Only populate the content sections.

## Special Characters

Escape all LaTeX special characters in user content:
- `&` → `\&`
- `%` → `\%`
- `#` → `\#`
- `$` → `\$` (unless already math mode)
- `_` → `\_` (outside math mode)
- URLs go inside `\href{url}{display}` — do not escape inside href arguments

## Placeholders

If a field is missing (e.g. no LinkedIn URL), use `[LINKEDIN\_URL]` as a visible placeholder so the user knows to fill it in.
